class Quote {

  String text;
  String auther;

  Quote({ required this.text, required this.auther });
}